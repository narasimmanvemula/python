DB Connection
    - DB Host
    - User id, password
    - Create a connection
    - A pool is setup 
        - connection pool
            allow to create 300 connections at any time

HTTP call
    - db connection is already established
        - connect to db as required
