## Dunder Method	Purpose
__init__	        Constructor, initializes the object
__str__	            String representation for print()
__repr__	        Official string representation
__len__	            Called when len(obj) is used
__eq__	            Defines equality == comparison
__lt__	            Defines < (less than) operator
__getitem__	        Allows indexing like a list

